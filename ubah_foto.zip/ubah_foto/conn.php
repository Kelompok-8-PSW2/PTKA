<?php 
// www.malasngoding.compact
// file penghubung antara database dengan php
$koneksi = mysqli_connect("localhost","root","","tutorial");
?>